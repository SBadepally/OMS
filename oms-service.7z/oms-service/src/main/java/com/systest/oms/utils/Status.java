package com.systest.oms.utils;

public class Status {
    Integer code;
    String message;

    Status(Integer code, String message) {
        this.code = code;
        this.message = message;
    }
}
